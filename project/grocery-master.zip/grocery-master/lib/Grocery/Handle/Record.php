<?php

namespace Grocery\Handle;

class Record extends Hasher
{
}
