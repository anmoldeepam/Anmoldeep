<?php

interface JsonSerializable {}
