<?php

namespace Grocery\Handle;

class Result extends Hasher
{
}
